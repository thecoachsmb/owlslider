/**
 * Created By : TheCoachSMB - Sonal Motghare-Balpande
 */
var config = {
    paths: {
        owlcarousel: "Thecoachsmb_OwlSlider/js/owl.carousel"
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};