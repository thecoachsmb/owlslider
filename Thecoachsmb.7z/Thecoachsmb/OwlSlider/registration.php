<?php
/**
 * Created By : TheCoachSMB - Sonal Motghare-Balpande
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Thecoachsmb_OwlSlider',
    __DIR__
);
